

```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

mouse_treatment = pd.read_csv("raw_data/mouse_drug_data.csv")
clinical_data = pd.read_csv("raw_data/clinicaltrial_data.csv")
mice_df = pd.merge(mouse_treatment, clinical_data,
                        how='outer', on='Mouse ID')
mice_df = mice_df.rename(columns = {"Tumor Volume (mm3)" : "Tumor_Volume"})
mice_df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Mouse ID</th>
      <th>Drug</th>
      <th>Timepoint</th>
      <th>Tumor_Volume</th>
      <th>Metastatic Sites</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>f234</td>
      <td>Stelasyn</td>
      <td>0</td>
      <td>45.000000</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>f234</td>
      <td>Stelasyn</td>
      <td>5</td>
      <td>47.313491</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>f234</td>
      <td>Stelasyn</td>
      <td>10</td>
      <td>47.904324</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>f234</td>
      <td>Stelasyn</td>
      <td>15</td>
      <td>48.735197</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>f234</td>
      <td>Stelasyn</td>
      <td>20</td>
      <td>51.112713</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
</div>




```python
capomulin_df = mice_df[mice_df.Drug == "Capomulin"]
timepoint_groups = capomulin_df.groupby('Timepoint')
colors = ["lightcoral", "deepskyblue", "olivedrab", "gold"]
x_values = []
y_values = []
for timepoint, group in timepoint_groups:
    x_values.append(timepoint)
    y_values.append(group['Tumor_Volume'].mean())
plt.scatter(x_values, y_values, marker="o", color = (colors[0]), alpha=0.75)
    
Infubinol_df = mice_df[mice_df.Drug == "Infubinol"]
timepoint_groups = Infubinol_df.groupby('Timepoint')

x_values1 = []
y_values1 = []
for timepoint, group in timepoint_groups:
    x_values1.append(timepoint)
    y_values1.append(group['Tumor_Volume'].mean())
plt.scatter(x_values1, y_values1, marker="o",color = (colors[1]), alpha=0.75)    

Ketapril_df = mice_df[mice_df.Drug == "Ketapril"]
timepoint_groups = Ketapril_df.groupby('Timepoint')
x_values2 = []
y_values2 = []
for timepoint, group in timepoint_groups:
    x_values2.append(timepoint)
    y_values2.append(group['Tumor_Volume'].mean())
plt.scatter(x_values2, y_values2, marker="o", color = (colors[2]), alpha=0.75)
    
Placebo_df = mice_df[mice_df.Drug == "Placebo"]
timepoint_groups = Placebo_df.groupby('Timepoint')
x_values3 = []
y_values3 = []
for timepoint, group in timepoint_groups:
    x_values3.append(timepoint)
    y_values3.append(group['Tumor_Volume'].mean())
plt.scatter(x_values3, y_values3, marker="o", color = (colors[3]), alpha=0.75)

plt.errorbar(x_values, y_values,yerr=np.std(y_values), linestyle = "None",
             ecolor=colors[0], alpha=0.75)
plt.errorbar(x_values1, y_values1,yerr=np.std(y_values1), linestyle="None",
             ecolor=colors[1], alpha=0.75)
plt.errorbar(x_values2, y_values2,yerr=np.std(y_values2), linestyle="None",
            ecolor = colors[2], alpha=0.75)
plt.errorbar(x_values3, y_values3,yerr=np.std(y_values3), linestyle="None", 
            ecolor = colors[3], alpha=0.75)
    
plt.title("Tumor Size over Trial Period")
plt.xlabel("Day of Treatment")
plt.ylabel("Mean Tumor Volume (mm3)")
plt.legend(labels=["Capomulin","Infubinol","Ketapril","Placebo"],
           loc="best")

plt.show()
    

```


![png](output_1_0.png)



```python
timepoint_groups = capomulin_df.groupby('Timepoint')
x_values = []
y_values = []
for timepoint, group in timepoint_groups:
    x_values.append(timepoint)
    y_values.append(group['Metastatic Sites'].mean())
plt.scatter(x_values, y_values, marker="o", color = (colors[0]), alpha=0.75)
    

timepoint_groups = Infubinol_df.groupby('Timepoint')

x_values1 = []
y_values1 = []
for timepoint, group in timepoint_groups:
    x_values1.append(timepoint)
    y_values1.append(group['Metastatic Sites'].mean())
plt.scatter(x_values1, y_values1, marker="o",color = (colors[1]), alpha=0.75)    


timepoint_groups = Ketapril_df.groupby('Timepoint')
x_values2 = []
y_values2 = []
for timepoint, group in timepoint_groups:
    x_values2.append(timepoint)
    y_values2.append(group['Metastatic Sites'].mean())
plt.scatter(x_values2, y_values2, marker="o", color = (colors[2]), alpha=0.75)
    

timepoint_groups = Placebo_df.groupby('Timepoint')
x_values3 = []
y_values3 = []
for timepoint, group in timepoint_groups:
    x_values3.append(timepoint)
    y_values3.append(group['Metastatic Sites'].mean())
plt.scatter(x_values3, y_values3, marker="o", color = (colors[3]), alpha=0.75)

plt.errorbar(x_values, y_values,yerr=np.std(y_values), linestyle = "None",
             ecolor=colors[0], alpha=0.75)
plt.errorbar(x_values1, y_values1,yerr=np.std(y_values1), linestyle="None",
             ecolor=colors[1], alpha=0.75)
plt.errorbar(x_values2, y_values2,yerr=np.std(y_values2), linestyle="None",
            ecolor = colors[2], alpha=0.75)
plt.errorbar(x_values3, y_values3,yerr=np.std(y_values3), linestyle="None", 
            ecolor = colors[3], alpha=0.75)
    
plt.title("Metastatic Sites over Trial Period")
plt.xlabel("Day of Treatment")
plt.ylabel("Mean Metastatic Sites")
plt.legend(labels=["Capomulin","Infubinol","Ketapril","Placebo"],
           loc="best")

plt.show()
    
```


![png](output_2_0.png)



```python
timepoint_groups = capomulin_df.groupby('Timepoint')
x_values = []
y_values = []
for timepoint, group in timepoint_groups:
    x_values.append(timepoint)
    y_values.append(group['Mouse ID'].count())
plt.scatter(x_values, y_values, marker="o", color = (colors[0]), alpha=0.75)
    

timepoint_groups = Infubinol_df.groupby('Timepoint')

x_values1 = []
y_values1 = []
for timepoint, group in timepoint_groups:
    x_values1.append(timepoint)
    y_values1.append(group['Mouse ID'].count())
plt.scatter(x_values1, y_values1, marker="o",color = (colors[1]), alpha=0.75)    


timepoint_groups = Ketapril_df.groupby('Timepoint')
x_values2 = []
y_values2 = []
for timepoint, group in timepoint_groups:
    x_values2.append(timepoint)
    y_values2.append(group['Mouse ID'].count())
plt.scatter(x_values2, y_values2, marker="o", color = (colors[2]), alpha=0.75)
    

timepoint_groups = Placebo_df.groupby('Timepoint')
x_values3 = []
y_values3 = []
for timepoint, group in timepoint_groups:
    x_values3.append(timepoint)
    y_values3.append(group['Mouse ID'].count())
plt.scatter(x_values3, y_values3, marker="o", color = (colors[3]), alpha=0.75)
    
plt.title("Mouse Survival")
plt.xlabel("Day of Treatment")
plt.ylabel("Mice Surviving")
plt.legend(labels=["Capomulin","Infubinol","Ketapril","Placebo"],
           loc="best")

plt.show()
    
```


![png](output_3_0.png)



```python
end_trial_df = mice_df[mice_df.Timepoint == 45]
drug_groups = end_trial_df.groupby('Drug')
drugs = []
tumor_end = []
for drug, group in drug_groups:
    drugs.append(drug)
    tumor_end.append(group['Tumor_Volume'].mean())
        
x_values = np.arange(len(drugs))
y_values = list(map(lambda x: x - 45, tumor_end))
colors = []
for value in y_values:
    if value < 0:
        colors.append('green')
    else:
        colors.append('r')
plt.bar(x_values, y_values, color= colors, alpha=0.5,
        tick_label=drugs)

bars = plt.bar(x_values, y_values, color= colors, alpha=0.5,
        tick_label=drugs)

for rect in bars:
    height = rect.get_height()
    plt.text(rect.get_x() + rect.get_width()/2.0, height, '%d' % int(height), ha='center', va='bottom')

                 
plt.title("Tumor Growth Over Trial")
plt.xlabel("Treatment Drug")
plt.ylabel("Tumor Change at 45 Days")
plt.xticks(rotation=90)
plt.show()

```


![png](output_4_0.png)


#Insight 1: Capoulin reduced tumor size over the trial and also improved survival. 
#It didn't prevent metastatisis however. 

#Insight 2: Infubinol didn't reduce tumor size or prevent metastisis, or improve survival

#Insight 3: Ketapril improved survival but doesn't reduce tumor size or reduce risk of metastisis
